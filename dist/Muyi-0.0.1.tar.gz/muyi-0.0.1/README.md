# muyi_utils

Some useful utils for GNNs and Deep Learning.
